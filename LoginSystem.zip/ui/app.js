import { login, register, logout } from "./utils/JWTAuth.js";

class App extends Component {

  async login(){
    let info = {
      email: "",
      password: ""
    };

    await login(info);

  }

  async register(){
    let info = {
      first_name: "",
      last_name: "",
      email: "",
      password: ""
    };

    await register(info); 
  }

   render() {

    return (
      <div className="container">
      <div className="row">
        <h1>React JWT Authentication Example</h1>

        <button className="btn btn-primary" onClick = { this.register }>Sign up</button>

        <button className="btn btn-primary" onClick = { this.login }>Log in</button>

        <button className="btn btn-primary" onClick = { logout }>Log out</button>

      </div>
      </div>
    );
  }
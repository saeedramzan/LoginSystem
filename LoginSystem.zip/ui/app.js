import { login, register, logout } from "./utils/JWTAuth.js";

class App extends Component {

  async login(){
    let info = {
      email: "ramzan@cyberglance.com",
      password: "1234567"
    };

    await login(info);

  }

  async register(){
    let info = {
      first_name: "kaima",
      last_name: "Abbes",
      email: "kaima.abbes@email.com",
      password: "123456789"
    };

    await register(info); 
  }

   render() {

    return (
      <div className="container">
      <div className="row">
        <h1>React JWT Authentication Example</h1>

        <button className="btn btn-primary" onClick = { this.register }>Sign up</button>

        <button className="btn btn-primary" onClick = { this.login }>Log in</button>

        <button className="btn btn-primary" onClick = { logout }>Log out</button>

      </div>
      </div>
    );
  }